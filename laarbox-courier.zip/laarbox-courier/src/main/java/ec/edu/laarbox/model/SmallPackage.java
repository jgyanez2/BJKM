package ec.edu.laarbox.model;

public class SmallPackage extends Package {

    public SmallPackage(double weightKg, double declaredValue, String description, String trackingCode, boolean fragile) {
        super(weightKg, declaredValue, description, trackingCode, fragile);
    }

    @Override
    protected void packContent() {
        System.out.println("Packing content in a small box...");
    }

    @Override
    protected void calculateBasePrice() {
        // Base: 5.00 + 0.5 per kg, + 1.5 fragile surcharge
        basePrice = 5.0 + (0.5 * weightKg);
        if (fragile) {
            basePrice += 1.5;
        }
    }
}

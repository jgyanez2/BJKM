package ec.edu.laarbox.view;

import ec.edu.laarbox.controller.ShipmentController;
import ec.edu.laarbox.model.Client;
import ec.edu.laarbox.model.Package;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class ShipmentForm extends JFrame {
    private JTextField txtId;
    private JTextField txtFullName;
    private JTextField txtPhoneNumber;
    private JTextField txtEmail;
    private JTextField txtAddress;
    private JCheckBox chkVip;

    private JTextField txtWeightKg;
    private JTextField txtDeclaredValue;
    private JTextArea txtDescription;
    private JTextField txtTrackingCode;
    private JCheckBox chkFragile;

    private JComboBox<String> cmbPackageSize;
    private JButton btnProcess;

    private final ShipmentController controller = new ShipmentController();

    public ShipmentForm() {
        setTitle("Laarbox - Shipment Processor");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(720, 640);
        setLocationRelativeTo(null);
        initComponents();
    }

    private void initComponents() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel clientPanel = buildClientPanel();
        JPanel packagePanel = buildPackagePanel();

        btnProcess = new JButton("Process Shipment");
        btnProcess.addActionListener(this::onProcessClicked);

        JPanel center = new JPanel(new GridLayout(1, 2, 10, 10));
        center.add(clientPanel);
        center.add(packagePanel);

        panel.add(center, BorderLayout.CENTER);
        panel.add(btnProcess, BorderLayout.SOUTH);

        setContentPane(panel);
    }

    private JPanel buildClientPanel() {
        JPanel p = new JPanel();
        p.setLayout(new GridBagLayout());
        p.setBorder(BorderFactory.createTitledBorder("Client"));

        GridBagConstraints gc = new GridBagConstraints();
        gc.insets = new Insets(4,4,4,4);
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.weightx = 1.0;

        txtId = new JTextField();
        txtFullName = new JTextField();
        txtPhoneNumber = new JTextField();
        txtEmail = new JTextField();
        txtAddress = new JTextField();
        chkVip = new JCheckBox("VIP");

        int r = 0;
        addRow(p, gc, r++, new JLabel("ID:"), txtId);
        addRow(p, gc, r++, new JLabel("Full Name:"), txtFullName);
        addRow(p, gc, r++, new JLabel("Phone Number:"), txtPhoneNumber);
        addRow(p, gc, r++, new JLabel("Email:"), txtEmail);
        addRow(p, gc, r++, new JLabel("Address:"), txtAddress);
        addRow(p, gc, r++, new JLabel("VIP:"), chkVip);

        return p;
    }

    private JPanel buildPackagePanel() {
        JPanel p = new JPanel();
        p.setLayout(new GridBagLayout());
        p.setBorder(BorderFactory.createTitledBorder("Package"));

        GridBagConstraints gc = new GridBagConstraints();
        gc.insets = new Insets(4,4,4,4);
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.weightx = 1.0;

        txtWeightKg = new JTextField();
        txtDeclaredValue = new JTextField();
        txtDescription = new JTextArea(5, 20);
        txtDescription.setLineWrap(true);
        txtDescription.setWrapStyleWord(true);
        txtTrackingCode = new JTextField();
        chkFragile = new JCheckBox("Fragile");
        cmbPackageSize = new JComboBox<>(new String[] {"Small", "Medium", "Large"});

        int r = 0;
        addRow(p, gc, r++, new JLabel("Weight (kg):"), txtWeightKg);
        addRow(p, gc, r++, new JLabel("Declared Value:"), txtDeclaredValue);
        addRow(p, gc, r++, new JLabel("Description:"), new JScrollPane(txtDescription));
        addRow(p, gc, r++, new JLabel("Tracking Code:"), txtTrackingCode);
        addRow(p, gc, r++, new JLabel("Fragile:"), chkFragile);
        addRow(p, gc, r++, new JLabel("Package Size:"), cmbPackageSize);

        return p;
    }

    private void addRow(JPanel panel, GridBagConstraints gc, int row, JComponent left, JComponent right) {
        gc.gridx = 0; gc.gridy = row; gc.weightx = 0.3;
        panel.add(left, gc);
        gc.gridx = 1; gc.gridy = row; gc.weightx = 0.7;
        panel.add(right, gc);
    }

    private void onProcessClicked(ActionEvent e) {
        try {
            Client client = buildClientFromForm();
            Package pkg = buildPackageFromForm();
            controller.processAndPersist(client, pkg);

            String message = buildSummaryMessage(client, pkg);
            JOptionPane.showMessageDialog(this, message, "Shipment Result", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private Client buildClientFromForm() {
        int id = Integer.parseInt(txtId.getText().trim());
        String fullName = txtFullName.getText().trim();
        String phoneNumber = txtPhoneNumber.getText().trim();
        String email = txtEmail.getText().trim();
        String address = txtAddress.getText().trim();
        boolean vip = chkVip.isSelected();
        return new Client(id, fullName, phoneNumber, email, address, vip);
    }

    private Package buildPackageFromForm() {
        String size = (String) cmbPackageSize.getSelectedItem();
        double weightKg = Double.parseDouble(txtWeightKg.getText().trim());
        double declaredValue = Double.parseDouble(txtDeclaredValue.getText().trim());
        String description = txtDescription.getText().trim();
        String trackingCode = txtTrackingCode.getText().trim();
        boolean fragile = chkFragile.isSelected();
        return controller.buildPackage(size, weightKg, declaredValue, description, trackingCode, fragile);
    }

    private String buildSummaryMessage(Client client, Package pkg) {
        StringBuilder sb = new StringBuilder();
        sb.append("=== Client ===\n")
          .append("ID: ").append(client.getId()).append('\n')
          .append("Full Name: ").append(client.getFullName()).append('\n')
          .append("Phone: ").append(client.getPhoneNumber()).append('\n')
          .append("Email: ").append(client.getEmail()).append('\n')
          .append("Address: ").append(client.getAddress()).append('\n')
          .append("VIP: ").append(client.isVip() ? "Yes" : "No").append("\n\n");

        sb.append("=== Package ===\n")
          .append("Size: ").append(pkg.getClass().getSimpleName()).append('\n')
          .append("Weight (kg): ").append(pkg.getWeightKg()).append('\n')
          .append("Declared Value: ").append(pkg.getDeclaredValue()).append('\n')
          .append("Description: ").append(pkg.getDescription()).append('\n')
          .append("Tracking Code: ").append(pkg.getTrackingCode()).append('\n')
          .append("Fragile: ").append(pkg.isFragile() ? "Yes" : "No").append("\n\n");

        sb.append("=== Pricing ===\n")
          .append("Original Price: $").append(String.format("%.2f", pkg.getBasePrice())).append('\n')
          .append("Final Price: $").append(String.format("%.2f", pkg.getFinalPrice())).append('\n');

        return sb.toString();
    }
}

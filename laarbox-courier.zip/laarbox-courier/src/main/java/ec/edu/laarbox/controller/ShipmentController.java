package ec.edu.laarbox.controller;

import ec.edu.laarbox.model.*;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;

public class ShipmentController {

    public Package buildPackage(String size, double weightKg, double declaredValue, String description, String trackingCode, boolean fragile) {
        switch (size) {
            case "Small":
                return new SmallPackage(weightKg, declaredValue, description, trackingCode, fragile);
            case "Medium":
                return new MediumPackage(weightKg, declaredValue, description, trackingCode, fragile);
            case "Large":
                return new LargePackage(weightKg, declaredValue, description, trackingCode, fragile);
            default:
                throw new IllegalArgumentException("Invalid package size: " + size);
        }
    }

    public void processAndPersist(Client client, Package pkg) {
        pkg.processShipment(client);
        persist(client, pkg);
    }

    private void persist(Client client, Package pkg) {
        MongoDatabase db = MongoDBConnection.getInstance().getDatabase();
        MongoCollection<Document> collection = db.getCollection("shipments");
        Document doc = new Document()
                .append("client", new Document()
                        .append("id", client.getId())
                        .append("fullName", client.getFullName())
                        .append("phoneNumber", client.getPhoneNumber())
                        .append("email", client.getEmail())
                        .append("address", client.getAddress())
                        .append("vip", client.isVip())
                )
                .append("package", new Document()
                        .append("size", pkg.getClass().getSimpleName())
                        .append("weightKg", pkg.getWeightKg())
                        .append("declaredValue", pkg.getDeclaredValue())
                        .append("description", pkg.getDescription())
                        .append("trackingCode", pkg.getTrackingCode())
                        .append("fragile", pkg.isFragile())
                )
                .append("pricing", new Document()
                        .append("basePrice", pkg.getBasePrice())
                        .append("finalPrice", pkg.getFinalPrice())
                );
        collection.insertOne(doc);
    }
}

package ec.edu.laarbox.model;

public abstract class Package {
    protected double weightKg;
    protected double declaredValue;
    protected String description;
    protected String trackingCode;
    protected boolean fragile;
    protected double basePrice;
    protected double finalPrice;
    protected DiscountStrategy discountStrategy;

    public Package(double weightKg, double declaredValue, String description, String trackingCode, boolean fragile) {
        this.weightKg = weightKg;
        this.declaredValue = declaredValue;
        this.description = description;
        this.trackingCode = trackingCode;
        this.fragile = fragile;
        this.discountStrategy = new NoDiscount();
    }

    // Template Method
    public final void processShipment(Client client) {
        registerPackage();
        packContent();
        transportPackage();
        calculateBasePrice();
        applyDiscount(client);
    }

    protected void registerPackage() {
        System.out.println("Registering package with tracking code: " + trackingCode);
    }

    protected abstract void packContent();

    protected void transportPackage() {
        System.out.println("Transporting package...");
    }

    // Allow each size to define base price rules and surcharges
    protected abstract void calculateBasePrice();

    protected void applyDiscount(Client client) {
        if (client.isVip()) {
            discountStrategy = new VipDiscount();
        } else {
            discountStrategy = new NoDiscount();
        }
        finalPrice = discountStrategy.applyDiscount(basePrice);
    }

    public double getBasePrice() { return basePrice; }
    public double getFinalPrice() { return finalPrice; }
    public double getWeightKg() { return weightKg; }
    public double getDeclaredValue() { return declaredValue; }
    public String getDescription() { return description; }
    public String getTrackingCode() { return trackingCode; }
    public boolean isFragile() { return fragile; }
}

package ec.edu.laarbox;

import ec.edu.laarbox.view.ShipmentForm;
import javax.swing.SwingUtilities;

public class MainApp {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            ShipmentForm form = new ShipmentForm();
            form.setVisible(true);
        });
    }
}

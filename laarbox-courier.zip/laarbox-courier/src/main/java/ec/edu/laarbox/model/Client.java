package ec.edu.laarbox.model;

public class Client {
    private int id;
    private String fullName;
    private String phoneNumber;
    private String email;
    private String address;
    private boolean vip;

    public Client(int id, String fullName, String phoneNumber, String email, String address, boolean vip) {
        this.id = id;
        this.fullName = fullName;
        this.phoneNumber = phoneNumber;
        this.email = email;
        this.address = address;
        this.vip = vip;
    }

    public int getId() {
        return id;
    }

    public String getFullName() {
        return fullName;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getEmail() {
        return email;
    }

    public String getAddress() {
        return address;
    }

    public boolean isVip() {
        return vip;
    }
}

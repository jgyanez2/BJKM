package ec.edu.laarbox.model;

public interface DiscountStrategy {
    double applyDiscount(double price);
}

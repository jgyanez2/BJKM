package ec.edu.laarbox.model;

public class LargePackage extends Package {

    public LargePackage(double weightKg, double declaredValue, String description, String trackingCode, boolean fragile) {
        super(weightKg, declaredValue, description, trackingCode, fragile);
    }

    @Override
    protected void packContent() {
        System.out.println("Packing content in a large box...");
    }

    @Override
    protected void calculateBasePrice() {
        // Base: 15.00 + 1.0 per kg, + 3.0 fragile surcharge
        basePrice = 15.0 + (1.0 * weightKg);
        if (fragile) {
            basePrice += 3.0;
        }
    }
}

package ec.edu.laarbox.model;

public class MediumPackage extends Package {

    public MediumPackage(double weightKg, double declaredValue, String description, String trackingCode, boolean fragile) {
        super(weightKg, declaredValue, description, trackingCode, fragile);
    }

    @Override
    protected void packContent() {
        System.out.println("Packing content in a medium box...");
    }

    @Override
    protected void calculateBasePrice() {
        // Base: 10.00 + 0.75 per kg, + 2.0 fragile surcharge
        basePrice = 10.0 + (0.75 * weightKg);
        if (fragile) {
            basePrice += 2.0;
        }
    }
}

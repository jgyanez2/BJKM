package ec.edu.espe.view;
import ec.edu.espe.model.*;

public class ClientApp {
    
    public static void main(String[] args) {
        GUIFactory factory = GUIFactory.getFactory();

        Button button = factory.createButton();
        button.setCaption("Guardar");
        button.paint();

        Menu menu = factory.createMenu();
        menu.setCaption("Menu principal");
        menu.paint();
    }
    
}

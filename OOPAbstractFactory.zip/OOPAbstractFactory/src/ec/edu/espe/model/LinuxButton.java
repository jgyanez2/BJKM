package ec.edu.espe.model;

public class LinuxButton extends Button {
    
    @Override
    public void paint() {
        System.out.println("Linux Button = " + caption);
        
    }
}
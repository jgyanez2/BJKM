package ec.edu.espe.model;

public class LinuxMenu extends Menu {
    
    @Override
    public void paint() {
        System.out.println("Linux Menu = " + caption);
        
    }
}
package ec.edu.espe.model;

public class WinButton extends Button {
    
    @Override
    public void paint() {
        System.out.println("Windows Button = " + caption);
        
    }
}
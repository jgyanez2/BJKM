#include <iostream>
#include <stdexcept>
#include "Grafo.h" // Importamos nuestra libreria propia

using namespace std;

int main() {
    try {
        int n, aristas;
        cout << "--- SISTEMA DE RUTAS DISCRETAS (Modular) ---" << endl;
        cout << "Ingrese cantidad de nodos: ";
        if (!(cin >> n)) throw runtime_error("Error de entrada.");

        // Creamos el objeto usando la clase definida en la libreria
        Grafo miGrafo(n);

        cout << "Ingrese cantidad de conexiones: ";
        cin >> aristas;

        cout << "Ingrese conexiones (Origen Destino Peso):" << endl;
        for (int i = 0; i < aristas; i++) {
            int u, v, w;
            cout << "Conexion " << (i + 1) << ": ";
            cin >> u >> v >> w;
            miGrafo.agregarArista(u, v, w);
        }

        miGrafo.mostrarMatriz();
        miGrafo.analizarGrados();

        int inicio, fin;
        cout << "\nIngrese nodo de Partida: ";
        cin >> inicio;
        cout << "Ingrese nodo de Llegada: ";
        cin >> fin;

        miGrafo.calcularRutaOptima(inicio, fin);

    } catch (const exception& e) {
        cerr << "\n[ERROR]: " << e.what() << endl;
        return 1;
    }

    return 0;
}

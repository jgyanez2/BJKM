#include "Grafo.h"
#include <iomanip>   // Para setw
#include <stdexcept> // Para manejo de errores
#include <vector>

using namespace std;

// Implementacion del Constructor
Grafo::Grafo(int n) {
    if (n <= 0) {
        throw invalid_argument("La cantidad de nodos debe ser positiva.");
    }
    cantidadNodos = n;
    // Redimensionamos la matriz n x n con valor infinito
    matriz.resize(n, vector<int>(n, INFINITO));

    // Diagonal en 0
    for (int i = 0; i < n; ++i) {
        matriz[i][i] = 0;
    }
}

// Implementacion de agregarArista
void Grafo::agregarArista(int u, int v, int peso) {
    if (u < 0 || u >= cantidadNodos || v < 0 || v >= cantidadNodos) {
        throw out_of_range("Nodo fuera de los limites permitidos.");
    }
    if (peso < 0) {
        throw invalid_argument("El peso no puede ser negativo.");
    }

    matriz[u][v] = peso;
    // OJO: Si ma�ana te piden bidireccional, descomenta la linea de abajo:
    // matriz[v][u] = peso;
}

// Implementacion de mostrarMatriz
void Grafo::mostrarMatriz() {
    cout << "\n--- MATRIZ DE ADYACENCIA (Ponderaciones) ---" << endl;
    cout << "      ";
    for(int k=0; k<cantidadNodos; k++) cout << "N" << k << "   ";
    cout << endl;

    for (int i = 0; i < cantidadNodos; i++) {
        cout << "N" << i << " | ";
        for (int j = 0; j < cantidadNodos; j++) {
            if (matriz[i][j] == INFINITO) {
                cout << setw(4) << "INF";
            } else {
                cout << setw(4) << matriz[i][j];
            }
            cout << " ";
        }
        cout << endl;
    }
}

// Implementacion de analizarGrados
void Grafo::analizarGrados() {
    cout << "\n--- ANALISIS DE GRADOS ---" << endl;
    for (int i = 0; i < cantidadNodos; i++) {
        int salida = 0;
        int entrada = 0;

        for (int j = 0; j < cantidadNodos; j++) {
            if (matriz[i][j] != INFINITO && i != j) salida++;
            if (matriz[j][i] != INFINITO && i != j) entrada++;
        }
        cout << "Nodo " << i << ": Sale a " << salida << " nodos | Recibe de " << entrada << " nodos" << endl;
    }
}

// Implementacion de calcularRutaOptima (Dijkstra)
void Grafo::calcularRutaOptima(int inicio, int fin) {
    if (inicio < 0 || inicio >= cantidadNodos || fin < 0 || fin >= cantidadNodos) {
        throw out_of_range("Nodos de inicio o fin no validos.");
    }

    vector<int> distancias(cantidadNodos, INFINITO);
    vector<bool> visitado(cantidadNodos, false);
    vector<int> padre(cantidadNodos, -1);

    distancias[inicio] = 0;

    for (int count = 0; count < cantidadNodos - 1; count++) {
        int minVal = INFINITO;
        int u = -1;

        for (int v = 0; v < cantidadNodos; v++) {
            if (!visitado[v] && distancias[v] <= minVal) {
                minVal = distancias[v];
                u = v;
            }
        }

        if (u == -1 || distancias[u] == INFINITO) break;

        visitado[u] = true;

        for (int v = 0; v < cantidadNodos; v++) {
            if (!visitado[v] && matriz[u][v] != INFINITO) {
                if (distancias[u] + matriz[u][v] < distancias[v]) {
                    distancias[v] = distancias[u] + matriz[u][v];
                    padre[v] = u;
                }
            }
        }
    }

    cout << "\n--- REPORTE DE DISTANCIA OPTIMA ---" << endl;
    if (distancias[fin] == INFINITO) {
        cout << "RESULTADO: No hay camino posible entre Nodo " << inicio << " y Nodo " << fin << endl;
    } else {
        cout << "RESULTADO: La distancia optima es " << distancias[fin] << endl;

        cout << "Ruta: " << fin;
        int actual = fin;
        while(padre[actual] != -1) {
            cout << " <- " << padre[actual];
            actual = padre[actual];
        }
        cout << endl;
    }
}

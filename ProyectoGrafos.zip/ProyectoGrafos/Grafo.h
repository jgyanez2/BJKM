#ifndef GRAFO_H
#define GRAFO_H

#include <vector>
#include <iostream>

// Definimos constante global para infinito
const int INFINITO = 100000000;

using namespace std;

class Grafo {
private:
    int cantidadNodos;
    // La matriz plana (cubo de informacion)
    vector<vector<int>> matriz;

public:
    // Constructor
    Grafo(int n);

    // Metodos (Funciones)
    void agregarArista(int u, int v, int peso);
    void mostrarMatriz();
    void analizarGrados();
    void calcularRutaOptima(int inicio, int fin);
};

#endif // GRAFO_H
